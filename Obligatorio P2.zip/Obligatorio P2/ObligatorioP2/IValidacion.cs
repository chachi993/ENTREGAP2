﻿using System;
namespace ObligatorioP2
{
    interface IValidacion // define los métodos de validación de datos que deben implementar los objetos. 
    {
        //declaramos el método para que sea utilizado.
        public bool EsValido();

        


    }
}
