﻿namespace ObligatorioP2
{
    public class Usuario
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public Roles Rol { get; set; }
        public int IdPersona { get; set; }


        public enum Roles { 
            Mozo,
            Cliente,
            Repartidor,
        }

    }
}